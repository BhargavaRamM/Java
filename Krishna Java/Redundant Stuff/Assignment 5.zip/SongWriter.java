public interface SongWriter
{
	public void writeSong(Song s);
}