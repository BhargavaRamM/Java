package SongStoreErrorCatch;

import java.awt.*;

import javax.swing.*;


public class ValidatingStorePanel extends StorePanel {

	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == exit)
			System.exit(0);
		if(e.getSource() == calculate) {

			
			if(payType.getSelectedItem().equals("")) {
				JOptionPane.showMessageDialog(this, "Enter your credit card number here.", "Credit Card Error", JOptionPane.ERROR_MESSAGE);
				return;
			}

			
			if(emailBox.getText().equals("")) {
				JOptionPane.showMessageDialog(this, "Enter your email address here.", "E-mail Error", JOptionPane.ERROR_MESSAGE);
				return;
			}


			if(nameBox.getText().equals("")) {
				JOptionPane.showMessageDialog(this, "Enter your name.", "Name Error", JOptionPane.ERROR_MESSAGE);
				return;
			}

			
			if(songs.getSelectedValuesList().size() == 0) {
				JOptionPane.showMessageDialog(this, "Please choose at least one song.", "Song Error", JOptionPane.ERROR_MESSAGE);
				return;
			}
			double total = 0;
			for(int i : songs.getSelectedIndices()) {
				total += songArray[i].getPrice();
			}
			totalCost.setText(String.format("$%.2f", total));
		}				


	}

}