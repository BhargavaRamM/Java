package SongStore;



public class Song {
	
	
	private String recordingArtist;
	private double price;
        private String songTitle;
	
	public Song(String recordingArtist, double price, String songTitle) {
		
		this.recordingArtist = recordingArtist;
		this.price = price;
                this.songTitle = songTitle;
	}
	
	public String getrecordingArtist() {
		return recordingArtist;
	}
	public void setrecordingArtist(String recordingArtist) {
		this.recordingArtist = recordingArtist;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
        
        public String getsongTitle() {
		return songTitle;
	}
	public void setTitle(String songTitle) {
		this.songTitle = songTitle;
	}

	public String toString() {
		return "Song Title: " + songTitle + "\nArtist: " + recordingArtist + "\nPrice: $"
				+ String.format("%.2f" ,price) + "\n";
	}
	
}