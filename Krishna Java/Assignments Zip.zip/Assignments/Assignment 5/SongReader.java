public interface SongReader
{
	public Song readSong();
}