package com.assets;
public interface SongReader {
	void readSong();
}