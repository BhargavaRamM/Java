package com.assets;
public interface SongWriter {
	void writeSong(Song s);
}